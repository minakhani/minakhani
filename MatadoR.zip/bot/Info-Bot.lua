bot_token = "694906296:AAEoLY9BdJGKRBOe63XwCgJgIk9zP6YevcI" -- توکن رباتُ
channel_username = '@sharjshou' -- آیدی کانال
channel_inline = 'sharjshou' -- آیدی کانال بدون @
sudo_username = '@mehdi_legend' -- آیدی سازنده ربات
gp_sudo = -1001349230237 -- آیدی گروه سودو ها
SUDO = 293259601 -- آیدی سودو اصلی
BotMaTaDoR_id = 694906296 --آیدی ربات cli
BotMaTaDoR_idapi = 511989794 --آیدی ربات api
RedisIndex = '1' -- شماره ردیس
EndPm = " ツ"

--[[
opened By @Megaian_Boy AND @Samyar65
My Channel @Megaian & @Bodyguard_Team
]]--